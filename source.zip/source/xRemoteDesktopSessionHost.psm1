<#
    This file is intentionally left empty. It is must be left here for the module
    manifest to refer to. It is recreated during the build process.
#>
