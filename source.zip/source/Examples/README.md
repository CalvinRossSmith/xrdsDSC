# Examples

This will help to understand how to setup certain scenarios with the
xRemoteDesktopSessionHost resource module.

## Resource examples

These are the links to the examples for each individual resource.

- [xRDGatewayConfiguration](Resources/xRDGatewayConfiguration)
- [xRDLicenseConfiguration](Resources/xRDLicenseConfiguration)
- [xRDRemoteApp](Resources/xRDRemoteApp)
- [xRDServer](Resources/xRDServer)
- [xRDSessionCollection](Resources/xRDSessionCollection)
- [xRDSessionCollectionConfiguration](Resources/xRDSessionCollectionConfiguration)
- [xRDSessionDeployment](Resources/xRDSessionDeployment)
